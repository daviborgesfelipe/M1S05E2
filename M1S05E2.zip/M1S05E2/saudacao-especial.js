//exportação de formar padrão ( default )
export default function digaNome() {
    let nome = "Davi Borges"
    return (`Olá, ${ nome }! Seja muito bem vindo!`);
}