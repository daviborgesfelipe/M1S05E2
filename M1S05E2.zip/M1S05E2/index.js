//Importa de forma padrão ( default )
import digaNome from "./saudacao-especial.js"
console.log(digaNome())
//Importa de forma nomeada, de forma individual
import {digaOla} from "./saudacao.js"
digaOla()