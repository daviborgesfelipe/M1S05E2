//exportação de forma nomeada
export function digaOla() {
    console.log(`Olá!`);
}